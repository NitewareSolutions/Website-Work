<section class="padding-2x background-dark full-width">
        <div class="line">
          <div class="s-12 l-6">
            <p class="text-size-12">Theme by Ali Abbas</p>
            <p class="text-size-12">All Rights Reserved &reg;</p>
          </div>
          <div class="s-12 l-6">
            <a class="right text-size-12 text-primary-hover" href="#" title="">Design and coding<br> by Ali Abbas</a>
          </div>
        </div>  
      </section>